%"Dynamic switching enables efficient bacterial colonization in flow", Kannan et al., 2018
%Compatibility: Matlab R2015aSP1
%written by Zhenbin Yang, Albert Siryaporn, and Anerudh Kannan 2016-2018

function results=bulkstartv1_1q(fullFileName, varargin)
%usage: bulkstart fullFileName
%       bulkstart fullFileName (optional speed)
%program simulates bulk and surface colonization
%program uses seeding (initialization) loops to generate starting bulk profile
currentversion='v1.1q';

[pathNametemp fileNametemp exttemp]=fileparts(fullFileName);
pathName=[pwd '/' pathNametemp '/'];
fileName=[fileNametemp exttemp];
loaded = load([pathName fileName], 'settings');
loaded_pre = load([pathName fileName], 'settings_pre');
settings=loaded.settings;
settings_pre=loaded_pre.settings_pre;
display(settings);
display(settings_pre);
fileName=strrep(fileName,'.mat',''); %change name for file saving
settings.currentversion=currentversion;

%parse arguments to allow either set upstream speed during command call or use speed value from
%settings
if (length(varargin) == 1)
    u=str2num(varargin{1});
    if isa(u,'numeric')
        settings.u=u;
        display (['your value is: ' num2str(settings.u) ' and is numeric']);
    else
        display (['your value is not numeric. using u=' num2str(settings.u) ' from settings']);
    end
else
    display(['no arguments sent. using u=' num2str(settings.u) ' from settings']);
end

%iterate through betas using l
for l=settings.bindexmin:settings.bindexmax
    %iterate velocities using k
    for k=settings.vindexmin:settings.vindexmax
        %specify initial conditions
        
        %C=surface population
        %D=bulk population
        C1previous=zeros(1,settings.numx);
        D1previous=zeros(1,settings.numx);
        C2previous=zeros(1,settings.numx);
        D2previous=zeros(1,settings.numx);
        
        C1previoussource = zeros(1,settings.numx);
        D1previoussource = zeros(1,settings.numx);
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %initial conditions
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %initial seeding of cells on the surface

        if strcmp(settings.seeding,'bulkevolve 2')
            %display (['here are your settings: ', settings_pre]);
            for i=1:settings_pre.numx
                %seed surface with a step function
                if settings_pre.x(i) < settings_pre.mu
                    D1previous(i) = 0;
                elseif settings_pre.x(i) <= settings_pre.mu + settings_pre.width && settings_pre.x(i) >= settings_pre.mu
                    D1previous(i) = settings_pre.amp;
                elseif settings_pre.x(i) >  settings_pre.mu + settings_pre.width
                    D1previous(i) = 0;
                end
                C1previous(i) = 0;
            end
            
            %pre-evolve the bulk population
            for m=1:settings_pre.initialt
                %plot final initial source population
                if settings_pre.plotfirstinterval==1 && settings_pre.plotinitialization==1
                    if m==1
                        window4=figure;
                        figure(window4)
                        plot(settings_pre.x, C1previous);
                        hold on;
                        plot(settings_pre.x, D1previous,'--');
                        title('initial of pre-initialization m=1');
                        %xlim([settings_pre.plotxmin settings_pre.plotxmax]);
                        drawnow;
                    end
                end
                
                %don't evolve for loop 1. This allows us to define an initial pattern that is seeded straight through to the main loop
                if m>1
                    results={};
                    results=evolve(C1previous, D1previous, C1previoussource, D1previoussource, C2previous, D2previous, settings_pre,l,k);
                    C1previous=results{1};
                    D1previous=results{2};
                    C1previoussource=results{3};
                    D1previoussource=results{4};
                end
                
                if mod(m,settings_pre.plotinitializationinterval)==0
                    time = settings_pre.dt*m;
                    display(['Bulk evolution loop: ' num2str(m) '. Time: ' sprintf('%2.2f hours',time/60)]);
                end
                
                surf1 = sum(C1previous*settings_pre.dx);
                surf2 = sum(C2previous*settings_pre.dx);
                bulk1 = sum(D1previous*settings_pre.dx);
                bulk2 = sum(D2previous*settings_pre.dx);
                time = settings_pre.dt*m;
                alph = settings_pre.alpha;
                bet = settings_pre.beta(l);
                exchange = settings_pre.f;
                speed = settings_pre.u;
                
                if settings_pre.plot==1 && settings_pre.plotinitialization==1
                    if m==1
                        window5=figure;
                        movegui(window5, 'northwest');
                    end
                    if mod(m,settings_pre.plotinitializationinterval)==0 && settings_pre.plotinitialization==1
                        figure(window5)
                        plot(settings_pre.x, C1previous);
                        hold on;
                        plot(settings_pre.x, D1previous,'--');
                        title('initialization surface/bulk');
                        drawnow;
                    end
                end
            end
            
            %Save results from initialization loop:
            if settings_pre.saveini ==1
                
                if m==1||mod(m,(settings_pre.initialt/200))==0
                    if m == 1
                        mkdir([pathName fileName 'Ini' num2str(settings_pre.u)]);
                    end
                    outputfilename=['bulkstart_INITIALIZATION' fileName '_' num2str(l) '_' num2str(settings_pre.u) '_' num2str(m) '.mat'];
                    save([pathName fileName 'Ini' num2str(settings_pre.u) '/' outputfilename],'settings_pre','C1previous','C1previoussource','D1previoussource','D1previous','C2previous','D2previous','m','time','alph','bet','surf1','surf2','bulk1','exchange','speed');
                end
            end
            
            %Options to for initializing surface to positive or zero
            if settings_pre.surfstart == 0
                %bulk remains the same. the surface and surface source go to 0
                C1previous=zeros(1,settings_pre.numx);
                C1previoussource=zeros(1,settings_pre.numx);
                D1previoussource=D1previous;
                D1previous=zeros(1,settings_pre.numx);
            elseif settings_pre.surfstart == 1
                D1previous=zeros(1,settings_pre.numx);
                D1previoussource=D1previous;
            elseif settings_pre.surfstart == 2
                C1previoussource=zeros(1,settings_pre.numx);
            elseif settings_pre.surfstart==3
            end
            
            %Renormalizing population density amplitude so it is independent of upstream velocity
            if strcmp(settings_pre.norm,'population')
                C1sourcepop = sum(C1previoussource*settings_pre.dx);
                D1sourcepop = sum(D1previoussource*settings_pre.dx);
                
                if C1sourcepop ~= 0
                    C1previoussource = C1previoussource/C1sourcepop;
                end
                
                if D1sourcepop ~= 0
                    D1previoussource = D1previoussource/D1sourcepop;
                end
                
                C1pop = sum(C1previous*settings_pre.dx);
                D1pop = sum(D1previous*settings_pre.dx);
                
                if C1pop ~= 0
                    C1previous = C1previous/C1pop;
                end
                
                if D1pop ~= 0
                    D1previous = D1previous/D1pop;
                end
            elseif strcmp(settings_pre.norm,'amplitude')
                C1sourcepop = max(C1previoussource*settings_pre.dx);
                D1sourcepop = max(D1previoussource*settings_pre.dx);
                
                if C1sourcepop ~=0
                    C1previoussource = C1previoussource/C1sourcepop;
                end
                
                if D1sourcepop ~=0
                    D1previoussource = D1previoussource/D1sourcepop;
                end
                
                C1pop = max(C1previous*settings_pre.dx);
                D1pop = max(D1previous*settings_pre.dx);
                
                if C1pop ~=0
                    C1previous = C1previous/C1pop;
                end
                
                if D1pop ~=0
                    D1previous = D1previous/D1pop;
                end
            elseif strcmp(settings_pre.norm,'none')
            end
            
            if settings_pre.truncation == 0
            elseif settings_pre.truncation == 1
                D1previous = (settings_pre.x>(settings_pre.mu)).*D1previous;
                D1previoussource=(settings_pre.x>(settings_pre.mu)).*D1previoussource;
            end
            
            %plot final initial source population
            if settings_pre.plotfirstinterval==1
                window3=figure;
                movegui(window3, 'northwest');
                figure(window3)
                plot(settings_pre.x, D1previoussource);
                hold on;
                plot(settings_pre.x, D1previous,'--');
                title('final pre-initial product');
                xlim([settings_pre.plotxmin settings_pre.plotxmax]);
                drawnow;
            end
        end
        %end of the settings.seeding cases
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %iterate difference equations; this starts the main loop
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %j=time iteration
        for j=1:settings.numt
            results={};
            results=evolve(C1previous, D1previous, C1previoussource, D1previoussource, C2previous, D2previous, settings,l,k);
            C1previous=results{1};
            D1previous=results{2};                 
            C1previoussource=results{3};
            D1previoussource=results{4};
            C2previous=results{5};
            D2previous=results{6};            
                        
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %save & plot results
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %display(['settings.beta l=' num2str(l) ', settings.u=', num2str(settings.u), ' time j=' num2str(j)]);
            if j==1||mod(j,settings.plotinterval)==0
                surf1 = sum(C1previous*settings.dx);
                surf2 = sum(C2previous*settings.dx);
                bulk1 = sum(D1previous*settings.dx);
                bulk2 = sum(D2previous*settings.dx);
                time = settings.dt*j;
                alph = settings.alpha;
                bet = settings.beta(l);
                exchange = settings.f;
                speed = settings.u;
                outputfilename=['bulkstart_' fileName '_' num2str(l) '_' num2str(settings.u) '_' num2str(j) '.mat'];
                if j ~= 1
                    timerval=toc;
                elseif j==1
                    timerval=0;
                    mkdir([pathName fileName]);
                end
                
                if settings.plot == 1
                    %plot surface density
                    if j==1
                        window1=figure;
                    end
                    if settings.plotfirstinterval==0 && j==1
                    else
                        figure(window1)
                        plot(settings.x, C1previous);
                        title('surface');
                        xlim([settings.plotxmin settings.plotxmax]);
                        drawnow;
                        hold on;
                    end
                    
                    %plot bulk density
                    if j==1
                        window2=figure;
                        movegui(window2, 'northeast');
                    end
                    if settings.plotfirstinterval==0 && j==1
                    else
                        figure(window2)
                        plot(settings.x, D1previous,'--');
                        title('bulk');
                        xlim([settings.plotxmin settings.plotxmax]);
                        drawnow;
                        hold on;
                    end
                    
                    %compare bulk and bulksource densities
                    if j==1
                        window6=figure;
                        movegui(window6, 'southeast');
                    end
                    if settings.plotfirstinterval==0 && j==1
                    else
                        figure(window6)
                        plot(settings.x, D1previous,'--');
                        hold on;
                        plot(settings.x, D1previoussource);
                        title('bulksource vs. bulk');
                        xlim([settings.plotxmin settings.plotxmax]);
                        drawnow;
                        hold on;
                    end
                end
                
                save([pathName fileName '/' outputfilename],'settings','C1previous','C1previoussource','D1previoussource','D1previous','C2previous','D2previous','j','time','alph','bet','surf1','surf2','bulk1','exchange','speed');
                
                display(['Saved ' outputfilename '. Time since last interval: ' num2str(timerval) '. Speed: ' num2str(speed) '. Simulated time: ' sprintf('%2.2f hours',time/60)]);
                tic;
            end
        end
    end
end
display('Done');
end

function results = evolve(C1previous, D1previous, C1previoussource, D1previoussource, C2previous, D2previous, settings, l, k)

if settings.sourcegrowth == 1
    %allow the sources to grow
    C1previoussource = (1+settings.dt*settings.alpha)*C1previoussource;
    D1previoussource = (1+settings.dt*settings.alpha)*D1previoussource;
else    
end

C1previous = C1previous + settings.wt*C1previoussource;
D1previous = D1previous + settings.wt*D1previoussource;

C1new=zeros(1,settings.numx);
D1new=zeros(1,settings.numx);
C2new=zeros(1,settings.numx);
D2new=zeros(1,settings.numx);

%compute bulk iterations
for i=3:settings.numx
    if i == 3|| i == settings.numx
        D1previous(i) = (1/3)*(4*D1previous(i-1)-D1previous(i-2));
        D2previous(i) = (1/3)*(4*D2previous(i-1)-D2previous(i-2));
    end
    D1new(i) = D1previous(i) - settings.v(k)* (settings.dt/(2*settings.dx))*(3*D1previous(i) - 4*D1previous(i-1)+D1previous(i-2))+settings.dt* settings.beta(l)* C1previous(i)+settings.dt* (settings.alpha-(1/settings.beta(l))) * D1previous(i);
    D2new(i) = D2previous(i) - settings.v(k)* (settings.dt/(2*settings.dx))*(3*D2previous(i) - 4*D2previous(i-1)+D2previous(i-2))+settings.dt* settings.beta(l)* C2previous(i)+settings.dt* (settings.alpha-(1/settings.beta(l))) * D2previous(i);
end

%compute surface iterations
for i=1:settings.numx-2
    if i==1
        C1previous(i) = (1/3)* (-C1previous(i+2)+4*C1previous(i+1));
        C2previous(i) = (1/3)* (-C2previous(i+2)+4*C2previous(i+1));
    end
    
    if settings.x(i)>settings.mu-settings.node
        C1new(i) = C1previous(i) + settings.u*(settings.dt/(2*settings.dx))*(-C1previous(i+2)+4*C1previous(i+1) - 3*C1previous(i))+settings.dt*(settings.alpha-settings.beta(l))* C1previous(i)+settings.dt* (1/settings.beta(l)) * D1previous(i) ;
        C2new(i) = C2previous(i) + settings.u*(settings.dt/(2*settings.dx))*(-C2previous(i+2)+4*C2previous(i+1) - 3*C2previous(i))+settings.dt*(settings.alpha-settings.beta(l))* C2previous(i)+settings.dt* (1/settings.beta(l)) * D2previous(i) ;
    else
        C1new(i) = C1previous(i) + settings.u*(settings.dt/(2*settings.dx))*(-C1previous(i+2)+4*C1previous(i+1) - 3*C1previous(i))+settings.dt*(settings.alpha-settings.beta(l))* C1previous(i)+settings.dt* (1/settings.beta(l)) * D1previous(i)+settings.dt*settings.f*(C2previous(i)-C1previous(i)) ;
        C2new(i) = C2previous(i) + settings.u*(settings.dt/(2*settings.dx))*(-C2previous(i+2)+4*C2previous(i+1) - 3*C2previous(i))+settings.dt*(settings.alpha-settings.beta(l))* C2previous(i)+settings.dt* (1/settings.beta(l)) * D2previous(i)+settings.dt*settings.f*(C1previous(i)-C2previous(i)) ;
    end
    
    if i == settings.numx-2
        C1new(i+1) = C1new(i);
        C2new(i+1) = C2new(i);
        C1new(i+2) = C1new(i);
        C2new(i+2) = C2new(i);
    end
end

if settings.jam == 1
    C1new = C1new + settings.jamFactor*(settings.mu-3*settings.sigma < settings.x & settings.x < settings.mu+ 3*settings.sigma).*C1new;
end

C1previous=(C1new>0).*C1new;
D1previous=(D1new>0).*D1new;

C2previous=(C2new>0).*C2new;
D2previous=(D2new>0).*D2new;

results = {C1previous D1previous C1previoussource D1previoussource C2previous D2previous};
end