%"Dynamic switching enables efficient bacterial colonization in flow", Kannan et al., 2018
%Compatibility: Matlab R2015aSP1
%written by Zhenbin Yang, Albert Siryaporn, and Anerudh Kannan 2016-2018

if isempty(mfilename)
    settings.outputfilename='test.mat';
else 
    settings.outputfilename=[mfilename, '.mat'];
end


%CELL PARAMETERS
settings.alpha=0.00696;            % 'settings.alpha' growth rate: doubling time
settings.beta=[0.0075 0.008 0.0085 0.009 0.0095 0.010 0.0105 0.011 0.012 0.0125 0.013 0.0135 0.014 0.0145 0.015 0.016 0.017 0.018 0.0215 0.035 0.04 0.06 0.08];
settings.beta=0.014;
settings.bindexmin=1;
settings.bindexmax=1;            %number of detachment iterations

%settings.eta=[100 20];            % 'settings.eta(m)' reattachment rate. this does nothing and does not appear anywhere else in the code

%FLOW
settings.v=[3000 5000 8000 10000 12000 15000];  %fluid velocity
settings.vindexmin=4;
settings.vindexmax=4;            %number of velocity iterations
settings.f=0.00;      % surface cross-over rate


%computation speed
settings.mode=3; %1=slow; 2=medium; 3=fast; 4=anemode; 5 = mode 2
if settings.mode==1
    %slow mode
    settings.numx = 8001;   %number of grid points in settings.x
    settings.dx = 3/10;
    settings.dt = 0.00001;  %CFL condition: (settings.dt * settings.v/settings.dx)=<0.5
elseif settings.mode==2
    %medium mode
    settings.numx = 801;   %number of grid points in settings.x
    settings.dx = 10*3/10;
    settings.dt = 0.0001;  %CFL condition: (settings.dt * settings.v/settings.dx)=<0.5
elseif settings.mode==3
    %fast mode
    settings.numx = 300;   %number of grid points in settings.x
    settings.dx = 100*3/10;
    settings.dt = 0.001;  %CFL condition: (settings.dt * settings.v/settings.dx)=<0.5
elseif settings.mode==4
    %ane mode
    settings.numx = 801;   %number of grid points in settings.x
    settings.dx = 10*3/10;
    settings.dt = 0.0001;  %CFL condition: (settings.dt * settings.v/settings.dx)=<0.5
elseif settings.mode==5
    %ane mode 2
    settings.numx = 1201;   %number of grid points in settings.x
    settings.dx = 10*3/10;
    settings.dt = 0.00005;  %CFL condition: (settings.dt * settings.v/settings.dx)=<0.5
else
    settings.numx = 801;   %number of grid points in settings.x
    settings.dx = 100*3/10;
    settings.dt = 0.001;  %CFL condition: (settings.dt * settings.v/settings.dx)=<0.5
end

settings.xf=20;          % left end
settings.x1=1;           %phase diagram location point
settings.x2=-1;          %phase diagram location point
settings.x = -70*settings.xf:settings.dx:settings.dx*(settings.numx-1)-70*settings.xf;   %vector of settings.x values, to be used for plotting

%initial conditions
settings.seeding='bulkevolve 2'; %b for bulk, s for surface, bulkevolve for bulkevolve
settings.surfstart = 0; % 1 for nonzero surface initialization; 0 for zero surface initialization
settings.wt = 1;
settings.amp = 1;
settings.sourcegrowth = 1;% 1 for source term doubling, 0 for fixed source term 
settings.initialt=1; %number of iterations for initial evolution for bulkevolve
settings.truncation = 1; %truncate the flow of cells into the channel?
settings.numt = 960000;  %total number of j (time) steps in the main channel

%Plotting information
settings.plot=0;
settings.plotfirstinterval=1;
settings.plotinitialization=0;
settings.plotinitializationinterval=10000;
settings.plotxmin=0;
settings.plotxmax=1000;
%settings.plotinterval=1/(settings.dt);
settings.plotinterval=500;
settings.initialize = 0;

settings.mu = 320; %center of the starting gaussian
settings.sigma = 15;
settings.node = 100; %spacing between the center of the starting gaussian and the node
settings.u=1;

settings.width = 200; % width of the loading channel
settings.jam = 0; % whether or not to allow jamming at node; 1 for yes, 0 for no
settings.jamFactor = 0.00000005 ; % 1.5% of C1new sticks to the node, increasing the population there at every iteration

%Loading loop options
settings.saveini =1; %1 for saving loading loop files, 0 for not saving
settings.motion = 0; %Does the population during loading have any upstream velocity ? 
settings.norm = 'none';%'population' for normalizing total cell population and 'amplitude' for normalizing surface density amplitude

%pre-initialization settings
settings_pre=settings;
settings_pre.beta=0.02;
settings_pre.u=0;
settings_pre.w=0;

save(settings.outputfilename, 'settings', 'settings_pre');
display(['Saved file: ' settings.outputfilename]);
close all; 
bulkstartv1_1q(settings.outputfilename);