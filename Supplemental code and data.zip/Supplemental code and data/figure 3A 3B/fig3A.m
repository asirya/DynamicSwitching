%"Dynamic switching enables efficient bacterial colonization in flow", Kannan et al., 2018
%Compatibility: Matlab R2015aSP1
%written by Zhenbin Yang, Albert Siryaporn, and Anerudh Kannan 2016-2018

%CELL PARAMETERS
alpha=0:0.001:0.04;            % 'alpha' growth rate: doubling time
beta=[0.0001 0.0025:.0025:0.1];        %detachment rate

%FLOW
v=1000;  %fluid velocity
u=1;    %upstream velocity (100x smaller than downstream??)
f=0.0;      % surface cross-over rate?

%GRID INFORMATION
numx = 1201;   %number of grid points in x
numt = 10000;  %number of time steps to be iterated

dx = 0.1;
dt = 0.00001;  %(dt * v/dx)=<0.5
settings.plotinterval=1/(dt);
xf=20;          % left end
x1=1;           %phase diagram location point
x2=-1;          %phase diagram location point
x =-10*xf:dx:dx*(numx-1)-10*xf;   %vector of x values, to be used for plotting

%VARIABLE INITIALIZATIONS
matrix1={};
matrix2={};
matrix3={};
matrix4={};

%PROGRAM CONTROL
bindexmax=41;            %number of detachment iterations
vindexmax=1;            %number of velocity iterations
aindexmax=41;

for l= 1:bindexmax
    for m=1:aindexmax
        for k = 1:vindexmax

        %specify initial conditions
        mu = -190;
        sigma = 1;
        
        C1previous=zeros(1,numx);
        D1previous=zeros(1,numx);

        %initial seed of cells on the surface
        for i=2:numx-1
            if ((mu-3*sigma) < x(i)) && (x(i) < (mu+3*sigma))
                C1previous(i) = exp(-(x(i)-mu)^2/(2*sigma^2)) / sqrt(2*pi*sigma^2);
                D1previous(i) = 0;
                
            end
        end
        
        for j=1:numt
            C1new=zeros(1,numx);
            D1new=zeros(1,numx);
            
            for i=3:numx
                if i == 3|| i == numx
                    D1previous(i) = (1/3)*(4*D1previous(i-1)-D1previous(i-2));
                end
                
                D1new(i) = D1previous(i) - v(k)* (dt/(2*dx))*(3*D1previous(i) - 4*D1previous(i-1)+D1previous(i-2))+dt* beta(l)* C1previous(i)+dt* (alpha(m)-(1/beta(l))) * D1previous(i);
            end
            
            for i=1:numx-2
                if i==1||i == numx-2
                    C1previous(i) = (1/3)* (-C1previous(i+2)+4*C1previous(i+1));
                end
                    C1new(i) = C1previous(i) + u*(dt/(2*dx))*(-C1previous(i+2)+4*C1previous(i+1) - 3*C1previous(i))+dt*(alpha(m)-beta(l))* C1previous(i)+dt* (1/beta(l)) * D1previous(i) ;
            end
            
            C1previous=(C1new>0).*C1new;
            D1previous=(D1new>0).*D1new;
  
            if j==1||mod(j,0.1*settings.plotinterval)==0
                surf1 = sum(C1new*dx);
                bulk1 = sum(D1new*dx);
                timestep = j;
                time = dt*j;
                alph = alpha(m);
                bet  = beta(l);
                vel  = v(k);
                save(['AB_v1000' num2str(l) '_' num2str(m) '_' num2str(j) '.mat'],'x','C1new','D1new','j','time','dx','dt','numx','numt','alph','bet','surf1','bulk1','vel');
            end
        end          
    end
    end
end