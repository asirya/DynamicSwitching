%"Dynamic switching enables efficient bacterial colonization in flow", Kannan et al., 2018
%Compatibility: Matlab R2015aSP1
%written by Zhenbin Yang, Albert Siryaporn, and Anerudh Kannan 2016-2018

%CELL PARAMETERS
alpha=0.03;            % 'alpha' growth rate: doubling time
beta=0;        %detachment rate

%FLOW
v=1000;  %fluid velocity
u=0;    %upstream velocity (100x smaller than downstream??)
f=0.1;      % surface cross-over rate?
diff = 1;

%GRID INFORMATION
numx = 12000;   %number of grid points in x
numt = 180000;  %number of time steps to be iterated

dx = 0.1;
dt = 0.001;  %(dt * v/dx)=<0.5 
settings.plotinterval=1/(dt);
xf=20;          % left end
x1=1;           %phase diagram location point
x2=-1;          %phase diagram location point
x = -15*xf:dx:dx*(numx-1)-15*xf;   %vector of x values, to be used for plotting

%VARIABLE INITIALIZATIONS
matrix1={};
matrix2={};
matrix3={};
matrix4={};

%PROGRAM CONTROL
bindexmax=13;            %number of detachment iterations
vindexmax=1;            %number of velocity iterations

for l = 1
    for k=1
        
        %specify initial conditions
        mu = 100;
        sigma = 1;
        
        C1previous=zeros(1,numx);
        C3previous=zeros(1,numx);
        C2previous=zeros(1,numx);
        C4previous=zeros(1,numx);
        
        %initial seed of cells on the surface
        for i=2:numx-1
            if ((mu-3*sigma) < x(i)) && (x(i) < (mu+3*sigma))
                C1previous(i) = exp(-(x(i)-mu)^2/(2*sigma^2)) / sqrt(2*pi*sigma^2);
            end
        end
     
        %iterate difference equations
        for j=1:numt
            C1new=zeros(1,numx);
            C2new=zeros(1,numx);
            C3new=zeros(1,numx);
            C4new=zeros(1,numx);

             for i=2:numx-3
                if x(i)> 50 
                    C1new(i) = C1previous(i) + u*(dt/(2*dx))*(-C1previous(i+2)+4*C1previous(i+1) - 3*C1previous(i))+dt*(alpha)* C1previous(i) +(dt*diff/(dx)^2)*(C1previous(i+1)-2*C1previous(i)+C1previous(i-1)) ;
                    C2new(i) = C2previous(i) + u*(dt/(2*dx))*(-C2previous(i+2)+4*C2previous(i+1) - 3*C2previous(i))+dt*(alpha)* C2previous(i) +(dt*diff/(dx)^2)*(C2previous(i+1)-2*C2previous(i)+C2previous(i-1));
                    C3new(i) = C3previous(i) + u*(dt/(2*dx))*(-C3previous(i+2)+4*C3previous(i+1) - 3*C3previous(i))+dt*(alpha)* C3previous(i)+(dt*diff/(dx)^2)*(C3previous(i+1)-2*C3previous(i)+C3previous(i-1));
                    C4new(i) = C4previous(i) + u*(dt/(2*dx))*(-C4previous(i+2)+4*C4previous(i+1) - 3*C4previous(i))+dt*(alpha)* C4previous(i) +(dt*diff/(dx)^2)*(C4previous(i+1)-2*C4previous(i)+C4previous(i-1));                    
                end
                
                if x(i) <= 50 && x(i) > 0
                    C1new(i) = C1previous(i) + u*(dt/(2*dx))*(-C1previous(i+2)+4*C1previous(i+1) - 3*C1previous(i))+dt*(alpha)* C1previous(i) +dt*f*(C2previous(i)-C1previous(i)) +(dt*diff/(dx)^2)*(C1previous(i+1)-2*C1previous(i)+C1previous(i-1)) ;
                    C2new(i) = C2previous(i) + u*(dt/(2*dx))*(-C2previous(i+2)+4*C2previous(i+1) - 3*C2previous(i))+dt*(alpha)* C2previous(i) +dt*f*(C1previous(i)-C2previous(i)) +(dt*diff/(dx)^2)*(C2previous(i+1)-2*C2previous(i)+C2previous(i-1));
                    C3new(i) = C3previous(i) + u*(dt/(2*dx))*(-C3previous(i+2)+4*C3previous(i+1) - 3*C3previous(i))+dt*(alpha)* C3previous(i) +dt*f*(C4previous(i)-C3previous(i)) +(dt*diff/(dx)^2)*(C3previous(i+1)-2*C3previous(i)+C3previous(i-1));
                    C4new(i) = C4previous(i) + u*(dt/(2*dx))*(-C4previous(i+2)+4*C4previous(i+1) - 3*C4previous(i))+dt*(alpha)* C4previous(i) +dt*f*(C3previous(i)-C4previous(i)) +(dt*diff/(dx)^2)*(C4previous(i+1)-2*C4previous(i)+C4previous(i-1)); 
                end
                
                if x(i) <= 0
                    C1new(i) = C1previous(i) + u*(dt/(2*dx))*(-C1previous(i+2)+4*C1previous(i+1) - 3*C1previous(i))+dt*(alpha)* C1previous(i) +dt*f*(C2previous(i)-C1previous(i))+(dt*diff/(dx)^2)*(C1previous(i+1)-2*C1previous(i)+C1previous(i-1));
                    C2new(i) = C2previous(i) + u*(dt/(2*dx))*(-C2previous(i+2)+4*C2previous(i+1) - 3*C2previous(i))+dt*(alpha)* C2previous(i) +dt*f*(C1previous(i)-C2previous(i)) +dt*f*(C3previous(i)-C2previous(i))+(dt*diff/(dx)^2)*(C2previous(i+1)-2*C2previous(i)+C2previous(i-1));
                    C3new(i) = C3previous(i) + u*(dt/(2*dx))*(-C3previous(i+2)+4*C3previous(i+1) - 3*C3previous(i))+dt*(alpha)* C3previous(i) +dt*f*(C2previous(i)-C3previous(i)) +dt*f*(C4previous(i)-C3previous(i)) +(dt*diff/(dx)^2)*(C3previous(i+1)-2*C3previous(i)+C3previous(i-1));
                    C4new(i) = C4previous(i) + u*(dt/(2*dx))*(-C4previous(i+2)+4*C4previous(i+1) - 3*C4previous(i))+dt*(alpha)* C4previous(i) +dt*f*(C3previous(i)-C4previous(i))  +(dt*diff/(dx)^2)*(C4previous(i+1)-2*C4previous(i)+C4previous(i-1));  
                end
            end

            C1previous=(C1new>0).*C1new;
            C2previous=(C2new>0).*C2new;
            C3previous=(C3new>0).*C3new;
            C4previous=(C4new>0).*C4new;
            
            if j==1||mod(j,1*settings.plotinterval)==0
                surf1 = sum(C1new*dx);
                surf2 = sum(C2new*dx);
                surf3 = sum(C3new*dx);
                surf4 = sum(C4new*dx);
                
                timestep = j;
                time = dt*j;
                alph = alpha;
                bet = beta(l);
                
                save(['hours3_Diffusion' num2str(l) '_' num2str(k) '_' num2str(j) '.mat'],'x','C1new','C2new','C3new','C4new','j','time','dx','dt','numx','numt','alph','bet');
            end
        end
        display(['l loop:' num2str(l) ', k loop:' num2str(k)]);
    end
end
display('Done');