%"Dynamic switching enables efficient bacterial colonization in flow", Kannan et al., 2018
%Compatibility: Matlab R2015aSP1
%written by Zhenbin Yang, Albert Siryaporn, and Anerudh Kannan 2016-2018

%CELL PARAMETERS
alpha=0.03;            % 'alpha' growth rate: doubling time
beta=[0.001 0.005 0.01 0.015 0.02 0.025 0.03 0.035 0.04 0.045 0.05 0.055 0.06 0.07 0.08 0.09 0.1 0.3];        %detachment rate

%FLOW
v=1000;  %fluid velocity
u=1;    %upstream velocity (100x smaller than downstream??)
f=0.1;      % surface cross-over rate?

%GRID INFORMATION
numx = 12000;   %number of grid points in x
numt=18000000;

dx = 0.1;
dt = 0.00001;  %(dt * v/dx)=<0.5 
settings.plotinterval=1/(dt);

% settings.plotinterval=100;
xf=20;          % left end
x1=1;           %phase diagram location point
x2=-1;          %phase diagram location point
x = -15*xf:dx:dx*(numx-1)-15*xf;   %vector of x values, to be used for plotting

%VARIABLE INITIALIZATIONS
matrix1={};
matrix2={};
matrix3={};
matrix4={};

%PROGRAM CONTROL
bindexmax=13;            %number of detachment iterations
vindexmax=1;            %number of velocity iterations

for l= 10
    for k=1:vindexmax
        %specify initial conditions
        mu = 100;
        sigma = 1;
        
        C1previous=zeros(1,numx);
        D1previous=zeros(1,numx);
        
        C3previous=zeros(1,numx);
        D3previous=zeros(1,numx);
        
        C2previous=zeros(1,numx);
        D2previous=zeros(1,numx);

        C4previous=zeros(1,numx);
        D4previous=zeros(1,numx);
        
        %initial seed of cells on the surface
        for i=2:numx-1
            if ((mu-3*sigma) < x(i)) && (x(i) < (mu+3*sigma))
                C1previous(i) = exp(-(x(i)-mu)^2/(2*sigma^2)) / sqrt(2*pi*sigma^2);
                D1previous(i) = 0;

            end
        end
        
        %iterate difference equations
        for j=1:numt
            C1new=zeros(1,numx);
            D1new=zeros(1,numx);
            C2new=zeros(1,numx);
            D2new=zeros(1,numx);
            C3new=zeros(1,numx);
            D3new=zeros(1,numx);
            C4new=zeros(1,numx);
            D4new=zeros(1,numx);
            
            for i=3:numx
                if i == 3|| i == numx
                    D1previous(i) = (1/3)*(4*D1previous(i-1)-D1previous(i-2));
                    D2previous(i) = (1/3)*(4*D2previous(i-1)-D2previous(i-2));
                    D3previous(i) = (1/3)*(4*D3previous(i-1)-D3previous(i-2));
                    D4previous(i) = (1/3)*(4*D4previous(i-1)-D4previous(i-2));
                end
                
                D1new(i) = D1previous(i) - v(k)* (dt/(2*dx))*(3*D1previous(i) - 4*D1previous(i-1)+D1previous(i-2))+dt* beta(l)* C1previous(i)+dt* (alpha-(1/beta(l))) * D1previous(i);
                D2new(i) = D2previous(i) - v(k)* (dt/(2*dx))*(3*D2previous(i) - 4*D2previous(i-1)+D2previous(i-2))+dt* beta(l)* C2previous(i)+dt* (alpha-(1/beta(l))) * D2previous(i);
                D3new(i) = D3previous(i) - v(k)* (dt/(2*dx))*(3*D3previous(i) - 4*D3previous(i-1)+D3previous(i-2))+dt* beta(l)* C3previous(i)+dt* (alpha-(1/beta(l))) * D3previous(i);
                D4new(i) = D4previous(i) - v(k)* (dt/(2*dx))*(3*D4previous(i) - 4*D4previous(i-1)+D4previous(i-2))+dt* beta(l)* C4previous(i)+dt* (alpha-(1/beta(l))) * D4previous(i);
            end
            
            for i=1:numx
                if i==1
                    C1previous(i) = (1/3)* (-C1previous(i+2)+4*C1previous(i+1));
                    C2previous(i) = (1/3)* (-C2previous(i+2)+4*C2previous(i+1));
                    C3previous(i) = (1/3)* (-C3previous(i+2)+4*C3previous(i+1));
                    C4previous(i) = (1/3)* (-C4previous(i+2)+4*C4previous(i+1));
                end
                
                if i <= numx-2
                    if x(i)> 50
                        C1new(i) = C1previous(i) + u*(dt/(2*dx))*(-C1previous(i+2)+4*C1previous(i+1) - 3*C1previous(i))+dt*(alpha-beta(l))* C1previous(i)+dt* (1/beta(l)) * D1previous(i) ;
                        C2new(i) = C2previous(i) + u*(dt/(2*dx))*(-C2previous(i+2)+4*C2previous(i+1) - 3*C2previous(i))+dt*(alpha-beta(l))* C2previous(i)+dt* (1/beta(l)) * D2previous(i) ;
                        C3new(i) = C3previous(i) + u*(dt/(2*dx))*(-C3previous(i+2)+4*C3previous(i+1) - 3*C3previous(i))+dt*(alpha-beta(l))* C3previous(i)+dt* (1/beta(l)) * D3previous(i) ;
                        C4new(i) = C4previous(i) + u*(dt/(2*dx))*(-C4previous(i+2)+4*C4previous(i+1) - 3*C4previous(i))+dt*(alpha-beta(l))* C4previous(i)+dt* (1/beta(l)) * D4previous(i) ;
                    end
                    
                    if x(i) <= 50 && x(i) > 0
                        C1new(i) = C1previous(i) + u*(dt/(2*dx))*(-C1previous(i+2)+4*C1previous(i+1) - 3*C1previous(i))+dt*(alpha-beta(l))* C1previous(i)+dt* (1/beta(l)) * D1previous(i) +dt*f*(C2previous(i)-C1previous(i))  ;
                        C2new(i) = C2previous(i) + u*(dt/(2*dx))*(-C2previous(i+2)+4*C2previous(i+1) - 3*C2previous(i))+dt*(alpha-beta(l))* C2previous(i)+dt* (1/beta(l)) * D2previous(i) +dt*f*(C1previous(i)-C2previous(i)) ;
                        C3new(i) = C3previous(i) + u*(dt/(2*dx))*(-C3previous(i+2)+4*C3previous(i+1) - 3*C3previous(i))+dt*(alpha-beta(l))* C3previous(i)+dt* (1/beta(l)) * D3previous(i) +dt*f*(C4previous(i)-C3previous(i)) ;
                        C4new(i) = C4previous(i) + u*(dt/(2*dx))*(-C4previous(i+2)+4*C4previous(i+1) - 3*C4previous(i))+dt*(alpha-beta(l))* C4previous(i)+dt* (1/beta(l)) * D4previous(i) +dt*f*(C3previous(i)-C4previous(i)) ;
                    end
                    
                    if x(i) <= 0
                        C1new(i) = C1previous(i) + u*(dt/(2*dx))*(-C1previous(i+2)+4*C1previous(i+1) - 3*C1previous(i))+dt*(alpha-beta(l))* C1previous(i)+dt* (1/beta(l)) * D1previous(i) +dt*f*(C2previous(i)-C1previous(i))+dt*(0)*(C3previous(i)-C1previous(i))+dt*(0)*(C4previous(i)-C1previous(i));
                        C2new(i) = C2previous(i) + u*(dt/(2*dx))*(-C2previous(i+2)+4*C2previous(i+1) - 3*C2previous(i))+dt*(alpha-beta(l))* C2previous(i)+dt* (1/beta(l)) * D2previous(i) +dt*f*(C1previous(i)-C2previous(i)) +dt*(0)*(C4previous(i)-C2previous(i)) +dt*f*(C3previous(i)-C2previous(i));
                        C3new(i) = C3previous(i) + u*(dt/(2*dx))*(-C3previous(i+2)+4*C3previous(i+1) - 3*C3previous(i))+dt*(alpha-beta(l))* C3previous(i)+dt* (1/beta(l)) * D3previous(i) +dt*f*(C2previous(i)-C3previous(i)) +dt*f*(C4previous(i)-C3previous(i)) +dt*(0)*(C1previous(i)-C3previous(i)) ;
                        C4new(i) = C4previous(i) + u*(dt/(2*dx))*(-C4previous(i+2)+4*C4previous(i+1) - 3*C4previous(i))+dt*(alpha-beta(l))* C4previous(i)+dt* (1/beta(l)) * D4previous(i) +dt*f*(C3previous(i)-C4previous(i)) +dt*(0)*(C2previous(i)-C4previous(i))+dt*(0)*(C1previous(i)-C4previous(i));
                    end
                end
                
                if i == numx-2
                    C1new(i+1) = C1new(i);
                    C2new(i+1) = C2new(i);
                    C3new(i+1) = C3new(i);
                    C4new(i+1) = C4new(i);
                    
                    C1new(i+2) = C1new(i) ;
                    C2new(i+2) = C2new(i) ;
                    C3new(i+2) = C3new(i) ;
                    C4new(i+2) = C4new(i) ;
                end
                
            end
            
            C1previous=(C1new>0).*C1new;
            D1previous=(D1new>0).*D1new;
            
            C2previous=(C2new>0).*C2new;
            D2previous=(D2new>0).*D2new;
            
            C3previous=(C3new>0).*C3new;
            D3previous=(D3new>0).*D3new;
            
            C4previous=(C4new>0).*C4new;
            D4previous=(D4new>0).*D4new;
            
            if j==1||mod(j,1*settings.plotinterval)==0
                surf1 = sum(C1new*dx);
                surf2 = sum(C2new*dx);
                surf3 = sum(C3new*dx);
                surf4 = sum(C4new*dx);
                
                bulk1 = sum(D1new*dx);
                bulk2 = sum(D2new*dx);
                bulk3 = sum(D3new*dx);
                bulk4 = sum(D4new*dx);
                
                timestep = j;
                time = dt*j;
                alph = alpha;
                bet = beta(l);

                figure(1)
                hold on;
                plot(x(1:numx),C1new(1:numx));
                
                 figure(2)
                 hold on;
                 plot(x(1:numx),D1new(1:numx));
                
                save(['hours3_NeumanBC_CFL0.1' num2str(l) '_' num2str(k) '_' num2str(j) '.mat'],'x','C1new','D1new','C2new','D2new','C3new','D3new','C4new','D4new','j','time','dx','dt','numx','numt','alph','bet');
            end
        end
        display(['l loop:' num2str(l) ', k loop:' num2str(k)]);
    end
end
display('Done');